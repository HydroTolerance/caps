<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
</head>
<body>
    <form method="post" action="faq.php">
        <label>Question:</label>
        <input type="text" name="question" required><br><br>
        <label>Answer:</label>
        <input type="text" name="answer" required><br><br>
        <input type="submit" name="submit" value="Submit">
        <a href="faq.php">Cancel</a>
    </form>
</body>
</html>
